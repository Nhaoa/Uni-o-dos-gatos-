# Jardim dos Gatos — edição modular

## Como executar
Abra `index.html` em um navegador. Para recursos do Firebase, use um servidor
local ou hospedagem HTTP/HTTPS (por exemplo, Live Server no VS Code).

## Estrutura
- `index.html`: estrutura da interface e pontos de montagem dos componentes.
- `assets/css/base.css`: estilos gerais e identidade visual.
- `assets/css/games.css`: estilos adicionais da área de jogos.
- `assets/js/00-tailwind-config.js`: configuração visual do Tailwind.
- `assets/js/01-svg-gatos.js`: geração dos gatos em SVG.
- `assets/js/02-firebase-e-estado.js`: inicialização do Firebase e sincronização.
- `assets/js/03-estado-e-carteiras.js`: estado compartilhado, carteiras e ações gerais.
- `assets/js/04-loja-e-atelie.js`: loja, itens e personalização.
- `assets/js/05-salas-online.js`: sincronização/listagem de salas.
- `assets/js/06-jokenpo.js`: lógica do jogo de Jokenpô.
- `assets/js/07-jogos-coletivos.js`: jogo da velha e Pata Rápida.
- `assets/js/08-air-hockey.js`: air hockey e pula-pula.
- `assets/js/09-xadrez-e-damas.js`: lógica de xadrez e damas.

## Convenções para alterações com IA
1. Antes de modificar uma funcionalidade, leia o arquivo JS correspondente e procure
   os elementos HTML associados em `index.html`.
2. Preserve os nomes das funções globais chamadas por `onclick`, `onchange` e outros
   atributos HTML. Muitas funções são expostas em `window`.
3. Os scripts clássicos são carregados na ordem numérica apresentada no HTML.
   Não altere essa ordem sem verificar dependências.
4. `02-firebase-e-estado.js` é um módulo ES (`type="module"`); mantenha imports e
   inicialização do Firebase nesse arquivo.
5. Evite duplicar variáveis globais `let`/`const` entre arquivos.
6. O projeto usa Tailwind via CDN e Firebase via CDN; esses recursos dependem de
   conexão com a internet.

## Segundo turno
A página e o botão de acesso à apuração do segundo turno foram removidos. O projeto
passa a ter somente a interface principal.


## Diagnóstico da sincronização
Se a sincronização continuar offline:
- Abra pelo mesmo endereço HTTP/HTTPS nos dois dispositivos (não misture `file://` com hospedagem).
- Verifique se o navegador tem acesso à internet.
- No Firebase Console, confirme que o provedor **Anonymous** está habilitado em Authentication.
- Confira as regras do Cloud Firestore para permitir leitura e escrita no caminho usado pelo app.
- Abra o Console do navegador (F12) e verifique erros de Firebase/Firestore.
